/**
 * @name GoogleSearchReplace
 * @authorId 278543574059057154
 * @invite Jx3TjNS
 * @donate https://www.paypal.me/MircoWittrien
 * @patreon https://www.patreon.com/MircoWittrien
 * @website https://github.com/mwittrien/BetterDiscordAddons/tree/master/Plugins/GoogleSearchReplace
 * @source https://raw.githubusercontent.com/mwittrien/BetterDiscordAddons/master/Plugins/GoogleSearchReplace/GoogleSearchReplace.plugin.js
 * @updateUrl https://raw.githubusercontent.com/mwittrien/BetterDiscordAddons/master/Plugins/GoogleSearchReplace/GoogleSearchReplace.plugin.js
 */

module.exports = (_ => {
	const config = {
		"info": {
			"name": "GoogleSearchReplace",
			"author": "DevilBro",
			"version": "1.2.9",
			"description": "Replace the default Google Text Search with a selection menu of several search engines"
		},
		"changeLog": {
			"added": {
				"GitHub": "Added github as search engine"
			}
		}
	};
	
	return !window.BDFDB_Global || (!window.BDFDB_Global.loaded && !window.BDFDB_Global.started) ? class {
		getName () {return config.info.name;}
		getAuthor () {return config.info.author;}
		getVersion () {return config.info.version;}
		getDescription () {return config.info.description;}
		
		load() {
			if (!window.BDFDB_Global || !Array.isArray(window.BDFDB_Global.pluginQueue)) window.BDFDB_Global = Object.assign({}, window.BDFDB_Global, {pluginQueue: []});
			if (!window.BDFDB_Global.downloadModal) {
				window.BDFDB_Global.downloadModal = true;
				BdApi.showConfirmationModal("Library Missing", `The library plugin needed for ${config.info.name} is missing. Please click "Download Now" to install it.`, {
					confirmText: "Download Now",
					cancelText: "Cancel",
					onCancel: _ => {delete window.BDFDB_Global.downloadModal;},
					onConfirm: _ => {
						delete window.BDFDB_Global.downloadModal;
						require("request").get("https://mwittrien.github.io/BetterDiscordAddons/Library/0BDFDB.plugin.js", (e, r, b) => {
							if (!e && b && b.indexOf(`* @name BDFDB`) > -1) require("fs").writeFile(require("path").join(BdApi.Plugins.folder, "0BDFDB.plugin.js"), b, _ => {});
							else BdApi.alert("Error", "Could not download BDFDB library plugin, try again some time later.");
						});
					}
				});
			}
			if (!window.BDFDB_Global.pluginQueue.includes(config.info.name)) window.BDFDB_Global.pluginQueue.push(config.info.name);
		}
		start() {this.load();}
		stop() {}
		getSettingsPanel() {
			let template = document.createElement("template");
			template.innerHTML = `<div style="color: var(--header-primary); font-size: 16px; font-weight: 300; white-space: pre; line-height: 22px;">The library plugin needed for ${config.info.name} is missing.\nPlease click <a style="font-weight: 500;">Download Now</a> to install it.</div>`;
			template.content.firstElementChild.querySelector("a").addEventListener("click", _ => {
				require("request").get("https://mwittrien.github.io/BetterDiscordAddons/Library/0BDFDB.plugin.js", (e, r, b) => {
					if (!e && b && b.indexOf(`* @name BDFDB`) > -1) require("fs").writeFile(require("path").join(BdApi.Plugins.folder, "0BDFDB.plugin.js"), b, _ => {});
					else BdApi.alert("Error", "Could not download BDFDB library plugin, try again some time later.");
				});
			});
			return template.content.firstElementChild;
		}
	} : (([Plugin, BDFDB]) => {
		const textUrlReplaceString = "DEVILBRO_BD_GOOGLESEARCHREPLACE_REPLACEURL";
		var settings = {}, engines = {}, enabledEngines = {};
	
		return class GoogleSearchReplace extends Plugin {
			onLoad() {
				this.defaults = {
					settings: {
						useChromium: 		{value: false,	description: "Use an inbuilt browser window instead of opening your default browser"},
					},
					engines: {
						_all: 				{value: true, 	name: BDFDB.LanguageUtils.LanguageStrings.FORM_LABEL_ALL, 	url: null},
						Ask: 				{value: true, 	name: "Ask", 					url: "https://ask.com/web?q=" + textUrlReplaceString},
						Bing: 				{value: true, 	name: "Bing", 					url: "https://www.bing.com/search?q=" + textUrlReplaceString},
						DogPile:			{value: true, 	name: "DogPile", 				url: "http://www.dogpile.com/search/web?q=" + textUrlReplaceString},
						DuckDuckGo:			{value: true, 	name: "DuckDuckGo", 			url: "https://duckduckgo.com/?q=" + textUrlReplaceString},
						GitHub: 			{value: true, 	name: "GitHub", 				url: "https://github.com/search?q=" + textUrlReplaceString},
						Google: 			{value: true, 	name: "Google", 				url: "https://www.google.com/search?q=" + textUrlReplaceString},
						GoogleScholar: 		{value: true, 	name: "Google Scholar", 		url: "https://scholar.google.com/scholar?q=" + textUrlReplaceString},
						Quora: 				{value: true, 	name: "Quora", 					url: "https://www.quora.com/search?q=" + textUrlReplaceString},
						Qwant: 				{value: true, 	name: "Qwant", 					url: "https://www.qwant.com/?t=all&q=" + textUrlReplaceString},
						UrbanDictionary: 	{value: true, 	name: "Urban Dictionary", 		url: "https://www.urbandictionary.com/define.php?term=" + textUrlReplaceString},
						Searx: 				{value: true, 	name: "Searx", 					url: "https://searx.info/?q=" + textUrlReplaceString},
						WolframAlpha:		{value: true, 	name: "Wolfram Alpha", 			url: "https://www.wolframalpha.com/input/?i=" + textUrlReplaceString},
						Yandex: 			{value: true, 	name: "Yandex", 				url: "https://yandex.com/search/?text=" + textUrlReplaceString},
						Yahoo: 				{value: true, 	name: "Yahoo", 					url: "https://search.yahoo.com/search?p=" + textUrlReplaceString},
						YouTube: 			{value: true, 	name: "YouTube", 				url: "https://www.youtube.com/results?q=" + textUrlReplaceString}
					}
				};
			}
			
			onStart() {
				this.forceUpdateAll();
			}
			
			onStop() {}

			getSettingsPanel (collapseStates = {}) {
				let settingsPanel, settingsItems = [];
				
				for (let key in settings) settingsItems.push(BDFDB.ReactUtils.createElement(BDFDB.LibraryComponents.SettingsSaveItem, {
					type: "Switch",
					plugin: this,
					keys: ["settings", key],
					label: this.defaults.settings[key].description,
					value: settings[key]
				}));
				settingsItems.push(BDFDB.ReactUtils.createElement(BDFDB.LibraryComponents.SettingsPanelList, {
					title: "Search Engines:",
					children: Object.keys(engines).filter(n => n && n != "_all").map(key => BDFDB.ReactUtils.createElement(BDFDB.LibraryComponents.SettingsSaveItem, {
						type: "Switch",
						plugin: this,
						keys: ["engines", key],
						label: this.defaults.engines[key].name,
						value: engines[key]
					}))
				}));
				
				return settingsPanel = BDFDB.PluginUtils.createSettingsPanel(this, settingsItems);
			}

			onSettingsClosed () {
				if (this.SettingsUpdated) {
					delete this.SettingsUpdated;
					this.forceUpdateAll();
				}
			}
			
			forceUpdateAll () {
				settings = BDFDB.DataUtils.get(this, "settings");
				engines = BDFDB.DataUtils.get(this, "engines");
				enabledEngines = BDFDB.ObjectUtils.filter(engines, n => n);
			}

			onMessageContextMenu (e) {
				this.injectItem(e);
			}

			onNativeContextMenu (e) {
				this.injectItem(e);
			}
			
			injectItem (e) {
				let [children, index] = BDFDB.ContextMenuUtils.findItem(e.returnvalue, {id: "search-google"});
				if (index > -1) {
					let text = document.getSelection().toString();
					let enginesWithoutAll = BDFDB.ObjectUtils.filter(enabledEngines, n => n != "_all", true);
					let engineKeys = Object.keys(enginesWithoutAll);
					if (engineKeys.length == 1) {
						children.splice(index, 1, BDFDB.ContextMenuUtils.createItem(BDFDB.LibraryComponents.MenuItems.MenuItem, {
							label: this.labels.context_googlesearchreplace.replace("...", this.defaults.engines[engineKeys[0]].name),
							id: children[index].props.id,
							persisting: true,
							action: event => {
								if (!event.shiftKey) BDFDB.ContextMenuUtils.close(e.instance);
								BDFDB.DiscordUtils.openLink(this.defaults.engines[engineKeys[0]].url.replace(textUrlReplaceString, encodeURIComponent(text)), !settings.useChromium, event.shiftKey);
							}
						}));
					}
					else {
						let items = [];
						for (let key in enabledEngines) items.push(BDFDB.ContextMenuUtils.createItem(BDFDB.LibraryComponents.MenuItems.MenuItem, {
							label: this.defaults.engines[key].name,
							id: BDFDB.ContextMenuUtils.createItemId(this.name, "search", key),
							color: key == "_all" ? BDFDB.LibraryComponents.MenuItems.Colors.DANGER : BDFDB.LibraryComponents.MenuItems.Colors.DEFAULT,
							persisting: true,
							action: event => {
								if (!event.shiftKey) BDFDB.ContextMenuUtils.close(e.instance);
								if (key == "_all") {
									for (let key2 in enginesWithoutAll) BDFDB.DiscordUtils.openLink(this.defaults.engines[key2].url.replace(textUrlReplaceString, encodeURIComponent(text)), settings.useChromium, event.shiftKey);
								}
								else BDFDB.DiscordUtils.openLink(this.defaults.engines[key].url.replace(textUrlReplaceString, encodeURIComponent(text)), settings.useChromium, event.shiftKey);
							}
						}));
						if (!items.length) items.push(BDFDB.ContextMenuUtils.createItem(BDFDB.LibraryComponents.MenuItems.MenuItem, {
							label: this.labels.submenu_disabled,
							id: BDFDB.ContextMenuUtils.createItemId(this.name, "disabled"),
							disabled: true
						}));
						children.splice(index, 1, BDFDB.ContextMenuUtils.createItem(BDFDB.LibraryComponents.MenuItems.MenuItem, {
							label: this.labels.context_googlesearchreplace,
							id: children[index].props.id,
							children: items
						}));
					}
				}
			}

			setLabelsByLanguage () {
				switch (BDFDB.LanguageUtils.getLanguage().id) {
					case "bg":		// Bulgarian
						return {
							context_googlesearchreplace:		"Търсене с ...",
							submenu_disabled:					"Всички инвалиди"
						};
					case "da":		// Danish
						return {
							context_googlesearchreplace:		"Søg med ...",
							submenu_disabled:					"Alle handicappede"
						};
					case "de":		// German
						return {
							context_googlesearchreplace:		"Suche mit ...",
							submenu_disabled:					"Alle deaktiviert"
						};
					case "el":		// Greek
						return {
							context_googlesearchreplace:		"Αναζήτηση με ...",
							submenu_disabled:					"Όλα τα άτομα με ειδικές ανάγκες"
						};
					case "es":		// Spanish
						return {
							context_googlesearchreplace:		"Buscar con ...",
							submenu_disabled:					"Todos discapacitados"
						};
					case "fi":		// Finnish
						return {
							context_googlesearchreplace:		"Hae ...",
							submenu_disabled:					"Kaikki vammaiset"
						};
					case "fr":		// French
						return {
							context_googlesearchreplace:		"Rechercher avec ...",
							submenu_disabled:					"Tout désactivé"
						};
					case "hr":		// Croatian
						return {
							context_googlesearchreplace:		"Traži sa ...",
							submenu_disabled:					"Svi invalidi"
						};
					case "hu":		// Hungarian
						return {
							context_googlesearchreplace:		"Keresés a következővel:",
							submenu_disabled:					"Minden fogyatékkal él"
						};
					case "it":		// Italian
						return {
							context_googlesearchreplace:		"Cerca con ...",
							submenu_disabled:					"Tutti disabilitati"
						};
					case "ja":		// Japanese
						return {
							context_googlesearchreplace:		"で検索 ...",
							submenu_disabled:					"すべて無効"
						};
					case "ko":		// Korean
						return {
							context_googlesearchreplace:		"다음으로 검색 ...",
							submenu_disabled:					"모두 비활성화 됨"
						};
					case "lt":		// Lithuanian
						return {
							context_googlesearchreplace:		"Ieškoti naudojant ...",
							submenu_disabled:					"Visi neįgalūs"
						};
					case "nl":		// Dutch
						return {
							context_googlesearchreplace:		"Zoeken met ...",
							submenu_disabled:					"Allemaal uitgeschakeld"
						};
					case "no":		// Norwegian
						return {
							context_googlesearchreplace:		"Søk med ...",
							submenu_disabled:					"Alle funksjonshemmede"
						};
					case "pl":		// Polish
						return {
							context_googlesearchreplace:		"Szukaj za pomocą ...",
							submenu_disabled:					"Wszystkie wyłączone"
						};
					case "pt-BR":	// Portuguese (Brazil)
						return {
							context_googlesearchreplace:		"Pesquise com ...",
							submenu_disabled:					"Todos desativados"
						};
					case "ro":		// Romanian
						return {
							context_googlesearchreplace:		"Căutați cu ...",
							submenu_disabled:					"Toate sunt dezactivate"
						};
					case "ru":		// Russian
						return {
							context_googlesearchreplace:		"Искать с ...",
							submenu_disabled:					"Все отключены"
						};
					case "sv":		// Swedish
						return {
							context_googlesearchreplace:		"Sök med ...",
							submenu_disabled:					"Alla funktionshindrade"
						};
					case "th":		// Thai
						return {
							context_googlesearchreplace:		"ค้นหาด้วย ...",
							submenu_disabled:					"ปิดใช้งานทั้งหมด"
						};
					case "tr":		// Turkish
						return {
							context_googlesearchreplace:		"Şununla ara ...",
							submenu_disabled:					"Hepsi devre dışı"
						};
					case "uk":		// Ukrainian
						return {
							context_googlesearchreplace:		"Шукати за допомогою ...",
							submenu_disabled:					"Всі інваліди"
						};
					case "vi":		// Vietnamese
						return {
							context_googlesearchreplace:		"Tìm kiếm với ...",
							submenu_disabled:					"Tất cả đã bị vô hiệu hóa"
						};
					case "zh":		// Chinese
						return {
							context_googlesearchreplace:		"用 ... 搜索",
							submenu_disabled:					"全部禁用"
						};
					case "zh-TW":	// Chinese (Traditional)
						return {
							context_googlesearchreplace:		"用 ... 搜索",
							submenu_disabled:					"全部禁用"
						};
					default:		// English
						return {
							context_googlesearchreplace:		"Search with ...",
							submenu_disabled:					"All disabled"
						};
				}
			}
		};
	})(window.BDFDB_Global.PluginUtils.buildPlugin(config));
})();
